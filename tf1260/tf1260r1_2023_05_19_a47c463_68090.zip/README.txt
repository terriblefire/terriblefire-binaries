Terriblefire TF1260 June 2022 Beta Release 2
------------------------------------------------

Always check tf1260.com for the latest firmware. 

TL;DR 

Builders MUST read the whole readme! 

Everyone else must update the tools (INCLUDED IN THE TFTOOLS.zip) file for every firmware release. 

-------------------------------------------------

Update produced while not on holiday in June 2022 due to contracting COVID-19. 

THIS FIRMWARE CAN NOW TO BE SUPPLIED AS PART OF A SALE. You are in breach of the license if you do not provide support to a buyer you sell to. Regardless of what you state in an eBay (or other commerce site) listing failure to provide support is grounds for returning the card, full refund. 

THIS IS ENTIRELY AT YOUR OWN RISK. IT WILL PROBABLY WIPE YOUR HARD DISK. NO WARANTY OF ANY KIND WITH THIS.

Also please make sure you can flash the previous version of the firmware before proceeding. If this does not work I want you to be able to get back to where you started from!!! If you're unsure wait for a later release. 

Your chipram speed may vary slightly with CPU speed. This is a consequence of moving data from 14Mhz domain into faster CPU speed. Some speeds will give faster chipram than others. 


Builders Section
--------

I'm more than happy for people to build and sell this card for a profit. However there are some conditions. 

You MUST provide support for the cards you build. Its fine for you to ask for help from other builders but you cannot just sell a card and leave me or other builders to support your work. Hence if you do not support the commercial sale license is revoked. 

Regardless of what you state on an ebay listing if you sell a TF1260 you MUST accept returns.


Speeds
------

You must update CPUSPEED to the latest version provided in the firmware pack. Available CPU Speeds (Note that some just dont work but reports of what does/doesnt work is appreciated. 75Mhz seems to be unfunctional at the moment)

50Mhz
58Mhz
60Mhz
62.5 Mhz
66.667Mhz (select 67 in cpuspeed) 
75Mhz (known unstable)
78 Mhz (known unstable)
80Mhz
82.5 Mhz
93.75 Mhz (Select 94 in cpuspeed)
100Mhz
125Mhz ...LOL

Some of these frequencies may be disabled in future if they arent stable. Best ones to try are 67 (66.6), 94 and 100. These are the most stable. 

IDE INTERFACE
-------------

Copy ehide.device to DEVS:

Obtain a copy of LoadModule from Aminet. Then to install the driver do 

LoadModule ehide.device 

The machine will reboot. 

FAQ
---------------------

Q. Where do I get the CPUSPEED tool from?
A. Its bundled with this firmware. 

Q. What is the 6ns firmware for? 
A. Its for people who have installed 6ns CPLDs vs 10ns on most boards. If you arent sure use 10ns.

Q. Which order are the CPLDs in the chain?
A. RAM first then BUS. 

Q. I just get a yellow screen with this firmware. 
A. Report that and just roll back to the previous revision. I'm still working on why. 

Q. What is the max speed of Rev X?
A. Its a rough guess but you can expect Rev1 will not overclock much. Rev 4 LC will do 100Mhz, Rev 6 FPU will do 94 or 100Mhz depending on the CPU. 

Q. What about cooling.
A. You're on our own there. Get a heatsink if you plan to run at 100Mhz. 

Q. Where do I get support?
A. Speak to whoever sold you your card. They must provide support.

Q. Where to i report new issues?
A. Exxos forum under the Terriblefire section. 

Tested Hardware
---------------
A1200 PAL R2B + Mask ROMS
A1200 PAL R2B + EPROMS 
A1200 PAL 1D4 + Mask ROMS
ReA1200 PAL 1D4 + EPROMS
A1200 NTSC 1D1 + Mask ROMS
CD32 Revision 3.

Stability
---------

I will always fix bugs as I find them. This particular firmware is alpha/unstable but soon we will have a stable release. Stable doesnt necessarilty mean final though and bug fixes will always happen as long as there is interest. 

CREDITS
-------

Firmware development was by Stephen Leary (Terriblefire). If you feel like making a small donation for continued FW development then paypal me at stephen@terriblefire.com. This is completely optional but it will buy me beers.

People ask me how long this took... In the 2 weeks leading up to the release of this I put in about 130 hours of effort... maybe more. This whole project has been 3-4000 hours of effort. Now just enjoy it ... thats all I ask. 

This project would not be possible without... 

John Hertell (ChuckyGang) - Not so Norwegian Solder dude. Has soldered almost 200 TF1260s and tested all the firmwares. 
Erik Hemming (erique) - Developer of the ehide.device driver (bundled)
Jamie Craig "Madhacker" - Lots of help with high speed side of things. :) 
Alen Marks (AlenPPC) - Soldering legend. Has soldered 150 TF1260s.... lots of NTSC testing.
Mark Brown (Superduper) - 150+ TF1260s Lots of soldering and testing. 
Chris "GadgetUK" - Testing and pimping of TF merch on his channel. 
Arek Makarenko - Testing and Polish Ambassador 
Go0se - Motherboards for testing.. lots of them 

Probably other people i forgot... sorry.